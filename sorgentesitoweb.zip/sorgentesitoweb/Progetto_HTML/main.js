function ricorsione(did, div) {
  if (did < div) {
    return did;
  } else {
    return ricorsione(did - div, div);
  }
}

function stampaResto() {
  if (document.myform.divisore.value == "" && document.myform.dividendo.value == "" || document.myform.divisore.value == "0" ) {
    document.getElementById("Resto").innerHTML = "Invio non effettuato. Il form sopra non può essere vuoto e/o la divisione per zero non è possibile!";
  } else {
    var dividendo_stringa = document.myform.dividendo.value;
    var divisore_stringa = document.myform.divisore.value;
    var dividendo = parseInt(dividendo_stringa);
    var divisore = parseInt(divisore_stringa);
    var resto = ricorsione(dividendo, divisore);
    console.log(resto);
    document.getElementById("Resto").innerHTML =
      "Resto: " + resto;
  }
}



//Questa cosa l'ho scritta io, portate rispetto anche se fa schifo
