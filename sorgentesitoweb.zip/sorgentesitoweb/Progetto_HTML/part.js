particlesJS.load('particles-js', 'particles.js-master/particles.json', function() {
  console.log('callback - particles.js config loaded');
});
